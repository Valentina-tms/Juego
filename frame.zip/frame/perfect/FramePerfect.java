package frame.perfect;

import Vista.MenuVista;
import Controlador.MenuController;
import javax.swing.SwingUtilities;

public class FramePerfect {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenuVista menu = new MenuVista();
            new MenuController(menu);
            menu.setVisible(true);
        });
    }
}
