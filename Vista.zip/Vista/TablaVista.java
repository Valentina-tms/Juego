package Vista;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

public class TablaVista extends JFrame {

    private JTable tabla;
    private DefaultTableModel modelo;
    private JButton btnCerrar;

    public TablaVista() {
        setTitle("Tabla de Posiciones — Frame Perfect");
        setSize(500, 420);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(15, 15, 15));
        setLayout(new BorderLayout(0, 0));

        // ── Título ──────────────────────────────────────────────
        JLabel titulo = new JLabel("🏆  TABLA DE POSICIONES", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setForeground(new Color(255, 215, 0));
        titulo.setBorder(BorderFactory.createEmptyBorder(16, 0, 10, 0));
        titulo.setBackground(new Color(15, 15, 15));
        titulo.setOpaque(true);
        add(titulo, BorderLayout.NORTH);

        // ── Tabla ───────────────────────────────────────────────
        String[] columnas = {"#", "Jugador", "Tiempo"};
        modelo = new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabla = new JTable(modelo);
        tabla.setBackground(new Color(25, 25, 25));
        tabla.setForeground(Color.WHITE);
        tabla.setGridColor(new Color(50, 50, 50));
        tabla.setFont(new Font("Consolas", Font.PLAIN, 14));
        tabla.setRowHeight(28);
        tabla.setShowVerticalLines(false);
        tabla.setSelectionBackground(new Color(60, 120, 80));

        // Encabezado
        JTableHeader header = tabla.getTableHeader();
        header.setBackground(new Color(30, 100, 60));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Arial", Font.BOLD, 14));
        header.setPreferredSize(new Dimension(0, 32));

        // Centrar columnas # y Puntaje
        DefaultTableCellRenderer centrado = new DefaultTableCellRenderer();
        centrado.setHorizontalAlignment(SwingConstants.CENTER);
        tabla.getColumnModel().getColumn(0).setCellRenderer(centrado);
        tabla.getColumnModel().getColumn(2).setCellRenderer(centrado);
        tabla.getColumnModel().getColumn(0).setPreferredWidth(40);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(260);
        tabla.getColumnModel().getColumn(2).setPreferredWidth(100);

        // Renderer con color alternado y top 3 dorado/plata/bronce
        tabla.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, val, sel, foc, row, col);
                setHorizontalAlignment(col == 1 ? SwingConstants.LEFT : SwingConstants.CENTER);
                if (!sel) {
                    if (row == 0)      { setBackground(new Color(180, 140, 0));  setForeground(Color.BLACK); }
                    else if (row == 1) { setBackground(new Color(130, 130, 130)); setForeground(Color.BLACK); }
                    else if (row == 2) { setBackground(new Color(140, 80, 30));  setForeground(Color.WHITE); }
                    else if (row % 2 == 0) { setBackground(new Color(28, 28, 28)); setForeground(Color.WHITE); }
                    else               { setBackground(new Color(22, 22, 22)); setForeground(Color.LIGHT_GRAY); }
                }
                setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 6));
                return this;
            }
        });

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));
        scroll.setBackground(new Color(15, 15, 15));
        scroll.getViewport().setBackground(new Color(15, 15, 15));
        add(scroll, BorderLayout.CENTER);

        // ── Botón cerrar ────────────────────────────────────────
        btnCerrar = new JButton("Cerrar");
        btnCerrar.setBackground(new Color(60, 60, 60));
        btnCerrar.setForeground(Color.WHITE);
        btnCerrar.setFocusPainted(false);
        btnCerrar.setFont(new Font("Arial", Font.BOLD, 13));
        btnCerrar.addActionListener(e -> dispose());
        JPanel sur = new JPanel();
        sur.setBackground(new Color(15, 15, 15));
        sur.setBorder(BorderFactory.createEmptyBorder(8, 0, 10, 0));
        sur.add(btnCerrar);
        add(sur, BorderLayout.SOUTH);
    }

    /** Limpia la tabla y carga los datos dados. */
    public void cargarDatos(java.util.List<String[]> datos) {
        modelo.setRowCount(0);
        int pos = 1;
        for (String[] fila : datos) {
            modelo.addRow(new Object[]{pos++, fila[0], fila[1]});
        }
        if (datos.isEmpty()) {
            modelo.addRow(new Object[]{"—", "Sin registros aún", "—"});
        }
    }
}
