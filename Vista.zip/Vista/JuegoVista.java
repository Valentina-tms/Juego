package Vista;

import Modelo.Enemigo;
import Modelo.Jugador;
import Modelo.Obstaculo;
import Modelo.PartidaModel;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.RenderingHints;
import Modelo.GestorImagenes;

public class JuegoVista extends JFrame {

    private PanelJuego panel;

    public JuegoVista() {
        setTitle("Frame Perfect");
        setSize(1200, 800);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        panel = new PanelJuego();
        add(panel);
        setLocationRelativeTo(null);
    }
    
    private JPanel overlayInstrucciones;

    public void mostrarInstrucciones(Runnable alContinuar) {
    overlayInstrucciones = new JPanel();
    overlayInstrucciones.setLayout(new BoxLayout(overlayInstrucciones, BoxLayout.Y_AXIS));
    overlayInstrucciones.setBackground(new Color(0, 0, 0, 200));
    overlayInstrucciones.setOpaque(true);
    overlayInstrucciones.setBounds(0, 0, getWidth(), getHeight());

    JLabel titulo = new JLabel("CÓMO JUGAR");
    titulo.setForeground(new Color(255, 215, 0));
    titulo.setFont(new Font("Arial", Font.BOLD, 36));
    titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

    String[] lineas = {
        "",
        "W / ↑    →  Moverte hacia arriba",
        "S / ↓    →  Moverte hacia abajo",
        "ESPACIO →  Saltar",
        "F        →  Disparar",
        "",
        "Esquiva los escombros y las balas de Mojo Jojo.",
        "¡Derrótalo antes de que te quite todas tus vidas!",
        "",
        "Tu tiempo se cronometra: ¡termina lo más rápido posible!"
    };

    JPanel textoPanel = new JPanel();
    textoPanel.setOpaque(false);
    textoPanel.setLayout(new BoxLayout(textoPanel, BoxLayout.Y_AXIS));
    for (String linea : lineas) {
        JLabel lbl = new JLabel(linea);
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Arial", Font.PLAIN, 20));
        lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        textoPanel.add(lbl);
    }

    JButton btnContinuar = new JButton("Continuar");
    btnContinuar.setFont(new Font("Arial", Font.BOLD, 20));
    btnContinuar.setAlignmentX(Component.CENTER_ALIGNMENT);
    btnContinuar.setPreferredSize(new Dimension(180, 50));
    btnContinuar.setMaximumSize(new Dimension(180, 50));

    overlayInstrucciones.add(Box.createVerticalGlue());
    overlayInstrucciones.add(titulo);
    overlayInstrucciones.add(Box.createRigidArea(new Dimension(0, 20)));
    overlayInstrucciones.add(textoPanel);
    overlayInstrucciones.add(Box.createRigidArea(new Dimension(0, 30)));
    overlayInstrucciones.add(btnContinuar);
    overlayInstrucciones.add(Box.createVerticalGlue());

    btnContinuar.addActionListener(e -> {
        getLayeredPane().remove(overlayInstrucciones);
        getLayeredPane().repaint();
        panel.requestFocusInWindow();   // devuelve el foco al panel del juego
        alContinuar.run();              // arranca el juego
    });

    getLayeredPane().add(overlayInstrucciones, JLayeredPane.POPUP_LAYER);
    }

    public void actualizar(Jugador jugador, PartidaModel partida) {
        panel.setDatos(jugador, partida);
        panel.repaint();
    }

    public PanelJuego getPanel() { return panel; }

    public class PanelJuego extends JPanel {
        private Jugador      jugador;
        private PartidaModel partida;

        public void setDatos(Jugador j, PartidaModel p) {
            this.jugador = j;
            this.partida = p;
        }

    @Override
    protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D) g;
    g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                        RenderingHints.VALUE_INTERPOLATION_BILINEAR);

    if (jugador == null || partida == null) return;

    // ── Fondo ─────────────────────────────────────────────
    BufferedImage fondo = GestorImagenes.get("fondo");
    if (fondo != null) g2.drawImage(fondo, 0, 0, getWidth(), getHeight(), null);
    else               { setBackground(new Color(53, 171, 82)); }

    // ── Jugador ───────────────────────────────────────────
    BufferedImage imgJug = GestorImagenes.get(jugador.getPersonaje());
    if (imgJug != null)
        g2.drawImage(imgJug, jugador.getX(), jugador.getY(), 45, 60, null);
    else {
        g2.setColor(Color.BLUE);
        g2.fillRect(jugador.getX(), jugador.getY(), 45, 60);
    }

    // ── Obstáculos (escombros) ────────────────────────────
    BufferedImage imgEsc = GestorImagenes.get("escombro");
    for (Modelo.Obstaculo o : partida.getObstaculos()) {
        if (imgEsc != null)
            g2.drawImage(imgEsc, o.getX(), o.getY(), o.getAncho(), o.getAlto(), null);
        else {
            g2.setColor(Color.WHITE);
            g2.fillRect(o.getX(), o.getY(), o.getAncho(), o.getAlto());
        }
    }

    // ── Balas del enemigo (laser rojo) ────────────────────
    BufferedImage imgLaserEne = GestorImagenes.get("laser");
    for (Modelo.BalaEnemigo b : partida.getBalasEnemigo()) {
        if (imgLaserEne != null)
            g2.drawImage(imgLaserEne, b.getX(), b.getY(),
                         Modelo.BalaEnemigo.ANCHO, Modelo.BalaEnemigo.ALTO, null);
        else {
            g2.setColor(new Color(255, 60, 0));
            g2.fillOval(b.getX(), b.getY(),
                        Modelo.BalaEnemigo.ANCHO, Modelo.BalaEnemigo.ALTO);
        }
    }

    // ── Balas del jugador (laser cyan) ────────────────────
    BufferedImage imgLaserJug = GestorImagenes.get("laser");
    for (Modelo.BalaJugador b : partida.getBalasJugador()) {
        if (imgLaserJug != null)
            g2.drawImage(imgLaserJug, b.getX(), b.getY(),
                         Modelo.BalaJugador.ANCHO, Modelo.BalaJugador.ALTO, null);
        else {
            g2.setColor(Color.CYAN);
            g2.fillOval(b.getX(), b.getY(),
                        Modelo.BalaJugador.ANCHO, Modelo.BalaJugador.ALTO);
        }
    }

    // ── Enemigos (Mojo Jojo) + barra de vida ──────────────
    BufferedImage imgEne = GestorImagenes.get("mojojojo");
    for (Modelo.Enemigo e : partida.getEnemigos()) {
        if (imgEne != null)
            g2.drawImage(imgEne, e.getX(), e.getY(), e.getAncho(), e.getAlto(), null);
        else {
            g2.setColor(Color.RED);
            g2.fillRect(e.getX(), e.getY(), e.getAncho(), e.getAlto());
        }

        // Barra de vida
        int barW = e.getAncho(), barH = 8;
        int barX = e.getX(),     barY = e.getY() - 14;
        g2.setColor(Color.DARK_GRAY);
        g2.fillRect(barX, barY, barW, barH);
        int vidaActual = (int)((float) e.getVida() / e.getVidaMax() * barW);
        g2.setColor(new Color(50, 220, 50));
        g2.fillRect(barX, barY, vidaActual, barH);
        g2.setColor(Color.WHITE);
        g2.drawRect(barX, barY, barW, barH);
    }

    // ── Puntaje ───────────────────────────────────────────
    g2.setColor(Color.WHITE);
    g2.setFont(new Font("Arial", Font.BOLD, 16));
    g2.drawString("Tiempo: " + jugador.getTiempoFormateado(), 10, 20);

    // ── Vidas ─────────────────────────────────────────────
    g2.setFont(new Font("Arial", Font.BOLD, 20));
    int vidas = jugador.getVidas();
    StringBuilder corazones = new StringBuilder();
    for (int i = 0; i < 3; i++) corazones.append(i < vidas ? "♥ " : "♡ ");
    g2.setColor(new Color(255, 60, 60));
    g2.drawString(corazones.toString().trim(), 10, 45);

    // ── Game Over ─────────────────────────────────────────
    if (partida.isGameOver() && !partida.isVictoria()) {
        g2.setColor(new Color(0, 0, 0, 150));
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.setColor(Color.YELLOW);
        g2.setFont(new Font("Arial", Font.BOLD, 40));
        g2.drawString("GAME OVER", 270, 200);
        g2.setFont(new Font("Arial", Font.BOLD, 20));
        g2.drawString("Tiempo final: " + jugador.getTiempoFormateado(), 310, 250);
    }

    // ── Victoria ──────────────────────────────────────────
    if (partida.isVictoria()) {
        g2.setColor(new Color(0, 0, 0, 150));
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.setColor(new Color(255, 215, 0));
        g2.setFont(new Font("Arial", Font.BOLD, 48));
        g2.drawString("¡VICTORIA!", 420, 280);
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.BOLD, 22));
        g2.drawString("¡Derrotaste al enemigo!", 420, 330);
        g2.drawString("Tiempo final:" + jugador.getTiempoFormateado(), 430, 365);
    }
    }  
    }
}
