package Vista;

import javax.swing.*;
import java.awt.*;

public class LoginVista extends JDialog {

    private JTextField     txtNombre;
    private JTextField     txtCorreo;
    private JPasswordField txtPassword;
    private JButton        btnLogin, btnRegistrar, btnCancelar;

    private String usuarioLogueado = null;
    private int    idUsuarioLogueado = -1;

    public LoginVista(JFrame parent) {
        super(parent, "Login — Frame Perfect", true);
        setSize(380, 310);
        setResizable(false);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(20, 20, 20));

        // ── Título ──────────────────────────────────────────────
        JLabel titulo = new JLabel("FRAME PERFECT", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        titulo.setForeground(new Color(80, 200, 120));
        titulo.setBorder(BorderFactory.createEmptyBorder(14, 0, 0, 0));
        titulo.setBackground(new Color(20, 20, 20));
        titulo.setOpaque(true);
        add(titulo, BorderLayout.NORTH);

        // ── Formulario ──────────────────────────────────────────
        JPanel form = new JPanel(new GridLayout(3, 2, 8, 10));
        form.setBackground(new Color(20, 20, 20));
        form.setBorder(BorderFactory.createEmptyBorder(10, 30, 0, 30));

        txtNombre   = campo();
        txtCorreo   = campo();
        txtPassword = new JPasswordField();
        estilizar(txtPassword);

        form.add(label("Usuario:"));    form.add(txtNombre);
        form.add(label("Correo (opt.)")); form.add(txtCorreo);
        form.add(label("Contraseña:")); form.add(txtPassword);
        add(form, BorderLayout.CENTER);

        // ── Botones ─────────────────────────────────────────────
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        botones.setBackground(new Color(20, 20, 20));

        btnLogin     = boton("Iniciar sesión", new Color(40, 130, 70));
        btnRegistrar = boton("Registrarse",    new Color(50, 90, 170));
        btnCancelar  = boton("Cancelar",       new Color(90, 35, 35));

        botones.add(btnLogin);
        botones.add(btnRegistrar);
        botones.add(btnCancelar);
        add(botones, BorderLayout.SOUTH);
    }

    // ── API pública ──────────────────────────────────────────────────────────

    public String getNombre()   { return txtNombre.getText().trim(); }
    public String getCorreo()   { return txtCorreo.getText().trim(); }
    public String getPassword() { return new String(txtPassword.getPassword()); }

    public JButton getBtnLogin()     { return btnLogin; }
    public JButton getBtnRegistrar() { return btnRegistrar; }
    public JButton getBtnCancelar()  { return btnCancelar; }

    public void setLoginExitoso(String nombre, int idUsuario) {
        this.usuarioLogueado   = nombre;
        this.idUsuarioLogueado = idUsuario;
    }

    public String getUsuarioLogueado()   { return usuarioLogueado; }
    public int    getIdUsuarioLogueado() { return idUsuarioLogueado; }

    public void mostrarError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
    public void mostrarExito(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private JLabel label(String t) {
        JLabel l = new JLabel(t);
        l.setForeground(Color.LIGHT_GRAY);
        l.setFont(new Font("Arial", Font.PLAIN, 13));
        return l;
    }

    private JTextField campo() {
        JTextField f = new JTextField();
        estilizar(f);
        return f;
    }

    private void estilizar(JTextField f) {
        f.setBackground(new Color(40, 40, 40));
        f.setForeground(Color.WHITE);
        f.setCaretColor(Color.WHITE);
        f.setBorder(BorderFactory.createLineBorder(new Color(70, 70, 70)));
    }

    private JButton boton(String t, Color bg) {
        JButton b = new JButton(t);
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setFont(new Font("Arial", Font.BOLD, 12));
        b.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 14));
        return b;
    }
}
