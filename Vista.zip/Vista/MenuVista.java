package Vista;

import java.awt.*;
import javax.swing.*;

public class MenuVista extends JFrame {

    private JButton btnPlay, btnTabla, btnLogin;
    private JLabel  lblUsuario;

    // ── Selector de personaje ─────────────────────────────────────
    private JComboBox<String> comboPersonaje;
    private String personajeSeleccionado = "burbuja";

    public MenuVista() {
        setTitle("Frame Perfect");
        setSize(1200, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setResizable(false);

    // Panel central con imagen de fondo
JPanel panelCentro = new JPanel() {
    private final Image imgMenu = new ImageIcon(
        getClass().getResource("/resources/menu.png")
    ).getImage();

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (imgMenu != null)
            g.drawImage(imgMenu, 0, 0, getWidth(), getHeight(), this);
    }
};
panelCentro.setOpaque(true);
add(panelCentro, BorderLayout.CENTER);

        // ── Panel inferior ──────────────────────────────────────
        JPanel panelSur = new JPanel(new BorderLayout());
        panelSur.setBackground(Color.black);
        panelSur.setBorder(BorderFactory.createEmptyBorder(0, 20, 10, 20));

        // Etiqueta usuario actual
        lblUsuario = new JLabel("Modo: Invitado", SwingConstants.LEFT);
        lblUsuario.setForeground(new Color(150, 150, 150));
        lblUsuario.setFont(new Font("Arial", Font.ITALIC, 13));
        panelSur.add(lblUsuario, BorderLayout.WEST);

        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        panelBotones.setBackground(Color.black);

        btnLogin = new JButton("Login");
        btnPlay  = new JButton("Play");
        btnTabla = new JButton("Tabla");

        Dimension tamBoton = new Dimension(150, 45);
        btnLogin.setPreferredSize(tamBoton);
        btnPlay.setPreferredSize(tamBoton);
        btnTabla.setPreferredSize(tamBoton);

        // Selector de personaje
        String[] personajes = {"burbuja", "bellota", "bombon"};
        comboPersonaje = new JComboBox<>(personajes);
        comboPersonaje.setSelectedItem("burbuja");
        comboPersonaje.setFont(new Font("Arial", Font.BOLD, 14));
        comboPersonaje.setPreferredSize(new Dimension(150, 45));
        comboPersonaje.addActionListener(e ->
            personajeSeleccionado = (String) comboPersonaje.getSelectedItem()
        );

        panelBotones.add(btnLogin);
        panelBotones.add(comboPersonaje);   // queda entre Login y Play
        panelBotones.add(btnPlay);
        panelBotones.add(btnTabla);

        panelSur.add(panelBotones, BorderLayout.CENTER);
        add(panelSur, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
    }

    /** Actualiza la etiqueta cuando el usuario se loguea. */
    public void setJugadorActual(String nombre) {
        lblUsuario.setText("Jugador: " + nombre);
        lblUsuario.setForeground(new Color(80, 200, 120));
        btnLogin.setText("✓ " + nombre);
    }

    public String  getPersonajeSeleccionado() { return personajeSeleccionado; }
    public JButton getbtnLogin()              { return btnLogin;  }
    public JButton getbtnPlay()               { return btnPlay;   }
    public JButton getbtnTabla()              { return btnTabla;  }
}